//Load the regular service worker
import "./vh_service_worker.js";

//Plugin line must be commented for official releases:
import "../plugins/_pluginsInit.js";
